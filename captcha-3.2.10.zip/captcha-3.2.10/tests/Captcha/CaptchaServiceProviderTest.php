<?php

namespace Mews\Tests\Captcha;

use PHPUnit\Framework\TestCase;

class CaptchaServiceProviderTest extends TestCase
{
    public function testRegister()
    {
        $this->assertTrue(true);
    }
}
